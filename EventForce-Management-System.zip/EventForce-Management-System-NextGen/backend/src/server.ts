import express from 'express';
import cors from 'cors';
import eventsRouter from './routes/events.js';
const app = express();
app.use(cors());
app.use(express.json());
app.get('/health', (_,res)=>res.json({ok:true, service:'EventForce NextGen', version:'2.0.0'}));
app.use('/api/events', eventsRouter);
app.listen(4000, ()=>console.log('EventForce NextGen API on http://localhost:4000'));
