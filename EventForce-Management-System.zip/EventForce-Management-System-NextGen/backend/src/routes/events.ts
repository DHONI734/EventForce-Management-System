import { Router } from 'express';
const router = Router();
const events = [
  { id:'1', name:'NEON Future Summit', status:'live', attendees:342, capacity:500 }
];
router.get('/', (req,res)=>res.json(events));
router.post('/', (req,res)=>{ const e={id:Date.now().toString(), ...req.body}; events.push(e); res.status(201).json(e); });
router.get('/:id', (req,res)=>{ const ev=events.find(x=>x.id===req.params.id); ev?res.json(ev):res.status(404).json({error:'not found'}); });
router.patch('/:id', (req,res)=>{ const idx=events.findIndex(x=>x.id===req.params.id); if(idx<0) return res.status(404).json({error:'not found'}); events[idx]={...events[idx], ...req.body}; res.json(events[idx]); });
export default router;
