export interface EventModel {
  id: string; name: string; description?: string;
  category: 'Conference'|'Music'|'Tech'|'Workshop'|'Corporate';
  status: 'draft'|'upcoming'|'live'|'completed'|'cancelled';
  date: string; time: string; location: string;
  capacity: number; attendees_count: number; progress: number; revenue: number;
  banner_gradient?: string; organizer_id?: string;
}
