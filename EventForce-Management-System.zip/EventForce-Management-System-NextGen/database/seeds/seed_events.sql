INSERT INTO events (name, category, status, date, time, location, capacity, attendees_count, progress, revenue) VALUES
('NEON Future Summit','Tech','live','2026-10-12','09:00','Chennai Trade Center',500,342,68,42000),
('Aether Music Festival','Music','upcoming','2026-10-18','17:30','Island Grounds',2000,1200,40,98000);
