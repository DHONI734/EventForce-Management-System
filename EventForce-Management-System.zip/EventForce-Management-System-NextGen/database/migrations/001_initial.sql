-- EventForce NextGen Schema
CREATE TABLE events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL, description TEXT,
  category TEXT CHECK (category IN ('Conference','Music','Tech','Workshop','Corporate')),
  status TEXT CHECK (status IN ('draft','upcoming','live','completed','cancelled')) DEFAULT 'draft',
  date DATE NOT NULL, time TIME NOT NULL, location TEXT NOT NULL,
  organizer_id UUID, capacity INT NOT NULL, attendees_count INT DEFAULT 0,
  progress INT DEFAULT 0, revenue DECIMAL DEFAULT 0, banner_gradient TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(), updated_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE TABLE attendees (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  event_id UUID REFERENCES events(id) ON DELETE CASCADE,
  name TEXT NOT NULL, email TEXT NOT NULL, ticket_type TEXT, checked_in BOOLEAN DEFAULT false
);
CREATE TABLE venues (id UUID PRIMARY KEY, name TEXT NOT NULL, address TEXT, capacity INT);
