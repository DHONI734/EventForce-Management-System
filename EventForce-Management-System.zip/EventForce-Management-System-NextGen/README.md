# EventForce Management System — NextGen
Next-Generation Event Management Platform

> Original project = READ ONLY reference. New project = COMPLETELY SEPARATE.
> Built at /EventForce-Management-System-NextGen/ — zero runtime dependency on original.

## Philosophy
READ OLD → UNDERSTAND OLD → BUILD NEW
Analyzed original for features, flows, auth, dashboard, forms, data, APIs, components.
Then discarded visually and rebuilt as premium command center.

Inspired by Linear + Stripe Dashboard + Vercel + Raycast

## Visual Identity (New)
- Colors: Deep Indigo #0F0B24, Electric Violet #7C3AED, Cyan #06B6D4, Aqua #5EEAD4, Coral #FF7A5C
- Typography: Space Grotesk (display), Inter (body)
- Language: Glassmorphism, grid, neon glow, soft shadows, real-time pulse

## Stack
Frontend: React 18 + TS + Vite + Tailwind
Backend: Node + Express + TS
Database: Postgres schema

## Structure
frontend/ (components/ui, events, dashboard, pages, styles/tokens.css, services/mockData.ts)
backend/ (routes/events.ts, server.ts)
database/migrations/001_initial.sql

## Run
cd frontend && npm i && npm run dev
cd backend && npm i && npm run dev

## Goal
"This is EventForce — but completely redesigned for the next generation."
Premium + Futuristic + Professional + Energetic + Intelligent + Clean
