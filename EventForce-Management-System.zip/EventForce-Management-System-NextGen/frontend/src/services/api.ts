const API = 'http://localhost:4000/api';
export async function getEvents(){ const r=await fetch(`${API}/events`); return r.json(); }
export async function createEvent(data:any){ const r=await fetch(`${API}/events`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)}); return r.json(); }
