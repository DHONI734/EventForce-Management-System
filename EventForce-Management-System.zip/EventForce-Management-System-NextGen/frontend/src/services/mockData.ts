export type EventStatus = 'draft' | 'upcoming' | 'live' | 'completed' | 'cancelled';
export interface Event {
  id: string; name: string; gradient: string; date: string; time: string;
  location: string; organizer: { name: string; initial: string };
  category: 'Conference'|'Music'|'Tech'|'Workshop'|'Corporate';
  attendees: number; capacity: number; status: EventStatus; progress: number; revenue: number;
}
export const events: Event[] = [
  { id:'1', name:'NEON Future Summit', gradient:'linear-gradient(135deg,#7C3AED 0%,#06B6D4 100%)', date:'Oct 12, 2026', time:'09:00 AM', location:'Chennai Trade Center', organizer:{name:'Aarav Mehta', initial:'AM'}, category:'Tech', attendees:342, capacity:500, status:'live', progress:68, revenue: 42000 },
  { id:'2', name:'Aether Music Festival', gradient:'linear-gradient(135deg,#FF7A5C 0%,#FB923C 100%)', date:'Oct 18, 2026', time:'05:30 PM', location:'Island Grounds', organizer:{name:'Lina Ray', initial:'LR'}, category:'Music', attendees:1200, capacity:2000, status:'upcoming', progress:40, revenue: 98000 },
  { id:'3', name:'Quantum DevCon 2026', gradient:'linear-gradient(135deg,#0F0B24 0%,#7C3AED 60%,#22D3EE 100%)', date:'Oct 21, 2026', time:'10:00 AM', location:'IIT Madras', organizer:{name:'Dev Team', initial:'DT'}, category:'Tech', attendees:89, capacity:300, status:'upcoming', progress:15, revenue: 21000 },
  { id:'4', name:'Bloom Wellness Retreat', gradient:'linear-gradient(135deg,#5EEAD4 0%,#06B6D4 100%)', date:'Oct 09, 2026', time:'07:00 AM', location:'ECR Beach Resort', organizer:{name:'Sana K', initial:'SK'}, category:'Workshop', attendees:64, capacity:80, status:'completed', progress:100, revenue: 12400 },
  { id:'5', name:'ArcLight Product Launch', gradient:'linear-gradient(135deg,#1A1040 0%,#FF7A5C 100%)', date:'Oct 14, 2026', time:'06:00 PM', location:'Tidel Park', organizer:{name:'ArcOfAnime', initial:'AA'}, category:'Corporate', attendees:210, capacity:250, status:'live', progress:52, revenue: 56000 },
  { id:'6', name:'SaaS Growth Conference', gradient:'linear-gradient(135deg,#8B5CF6 0%,#E0F2FE 100%)', date:'Oct 25, 2026', time:'09:30 AM', location:'ITC Grand', organizer:{name:'Growth Labs', initial:'GL'}, category:'Conference', attendees:0, capacity:400, status:'draft', progress:0, revenue:0 },
  { id:'7', name:'Chennai Design Week', gradient:'linear-gradient(135deg,#06B6D4 0%,#E0F2FE 100%)', date:'Nov 02, 2026', time:'11:00 AM', location:'DakshinChitra', organizer:{name:'Design Co', initial:'DC'}, category:'Workshop', attendees:156, capacity:300, status:'upcoming', progress:30, revenue: 18000 },
  { id:'8', name:'Midnight Protocol', gradient:'linear-gradient(135deg,#0F0B24 0%,#FF7A5C 100%)', date:'Oct 05, 2026', time:'10:00 PM', location:'Underground', organizer:{name:'Noir', initial:'N'}, category:'Music', attendees:400, capacity:400, status:'completed', progress:100, revenue: 34000 },
  { id:'9', name:'Cancelled: Monsoon Hack', gradient:'linear-gradient(135deg,#475569 0%,#94A3B8 100%)', date:'Oct 08, 2026', time:'09:00 AM', location:'Online', organizer:{name:'Hack Club', initial:'HC'}, category:'Tech', attendees:0, capacity:1000, status:'cancelled', progress:0, revenue:0 },
];
