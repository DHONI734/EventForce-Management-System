import React, { useState } from 'react';
import './styles/globals.css';
import { events } from './services/mockData';
import { Card } from './components/ui/Card';
import { StatusBadge } from './components/ui/Badge';
import { Button } from './components/ui/Button';
import { EventCard } from './components/events/EventCard';

export default function App(){
  const [theme, setTheme] = useState<'light'|'dark'>('light');
  const [filter, setFilter] = useState('All');
  const filtered = filter==='All'? events : events.filter(e=>e.category===filter || e.status===filter);
  return (
    <div data-theme={theme} className="min-h-screen bg-[var(--bg-app)]">
      <header className="h-16 border-b border-[var(--border)] flex items-center justify-between px-6 sticky top-0 z-20 bg-[var(--bg-surface)]/80 backdrop-blur">
        <h1 className="font-display font-bold text-xl tracking-tight">EVENTFORCE • <span className="text-violet-600">NEXTGEN</span></h1>
        <div className="flex gap-2"><Button variant="secondary" onClick={()=>setTheme(theme==='light'?'dark':'light')}>Theme: {theme}</Button><Button variant="primary">+ New Event</Button></div>
      </header>
      <div className="flex">
        <aside className="hidden lg:block w-[240px] border-r border-[var(--border)] min-h-[calc(100vh-64px)] p-4 space-y-2 bg-[var(--bg-surface)]">
          {['Dashboard','Events','Calendar','Venues','Attendees','Teams','Tasks','Analytics','Settings'].map(i=>(
            <div key={i} className={`px-3 py-2 rounded-xl text-sm ${i==='Events'?'bg-violet-600 text-white':'text-[var(--text-secondary)] hover:bg-[var(--bg-surface-2)]'}`}>{i}</div>
          ))}
        </aside>
        <main className="flex-1 p-6">
          <div className="flex gap-2 mb-6 flex-wrap">
            {['All','Tech','Music','Conference','Workshop','Corporate','live','upcoming'].map(c=>(
              <button key={c} onClick={()=>setFilter(c)} className={`px-3 py-1.5 rounded-full text-xs font-medium border ${filter===c?'bg-violet-600 text-white border-violet-600':'bg-[var(--bg-surface)] border-[var(--border)]'}`}>{c}</button>
            ))}
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
            {filtered.map(ev=>(<EventCard key={ev.id} event={ev} onClick={()=>alert(ev.name)} />))}
          </div>
          <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card className="p-5"><div className="text-xs text-[var(--text-tertiary)]">Total Events</div><div className="text-2xl font-display font-bold">127</div></Card>
            <Card className="p-5"><div className="text-xs text-[var(--text-tertiary)]">Live Revenue</div><div className="text-2xl font-display font-bold">$342K</div></Card>
            <Card className="p-5"><div className="text-xs text-[var(--text-tertiary)]">Utilization</div><div className="text-2xl font-display font-bold">87%</div></Card>
          </div>
        </main>
      </div>
    </div>
  )
}
