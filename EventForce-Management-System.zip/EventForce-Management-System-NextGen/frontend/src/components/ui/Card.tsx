import React from 'react';
export const Card: React.FC<{children: React.ReactNode, className?:string, hover?:boolean}> = ({children, className='', hover}) => (
  <div className={`rounded-[20px] border border-[var(--border)] bg-[var(--bg-surface)] shadow-[var(--shadow-sm)] ${hover ? 'hover:shadow-[var(--shadow-lg)] hover:-translate-y-[2px] transition-all duration-300 hover:border-violet-200' : ''} ${className}`}>{children}</div>
)
