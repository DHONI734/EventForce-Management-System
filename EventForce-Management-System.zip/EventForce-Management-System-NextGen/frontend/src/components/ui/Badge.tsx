import React from 'react';
import type { EventStatus } from '../../services/mockData';
export const StatusBadge: React.FC<{status: EventStatus}> = ({status}) => {
  const map: Record<EventStatus, string> = {
    live: 'bg-emerald-500/15 text-emerald-600 border-emerald-500/30',
    upcoming: 'bg-violet-500/10 text-violet-600 border-violet-500/20',
    draft: 'bg-zinc-500/10 text-zinc-600 border-zinc-500/20',
    completed: 'bg-cyan-500/10 text-cyan-700 border-cyan-500/20',
    cancelled: 'bg-red-500/10 text-red-600 border-red-500/20'
  };
  return (
    <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-semibold tracking-wide border ${map[status]} uppercase`}>
      {status==='live' && <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-[pulse-dot_1.5s_infinite]" />}
      {status}
    </span>
  )
}
