import React from 'react';
export const Button: React.FC<{variant?: 'primary'|'secondary'|'ghost', children: React.ReactNode, onClick?:()=>void, className?:string, type?:any}> = ({variant='primary', children, onClick, className='', type='button'}) => {
  const base = "inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-[12px] text-sm font-medium transition-all active:scale-[0.98] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-500";
  const variants = {
    primary: "bg-gradient-to-br from-violet-600 to-cyan-500 text-white shadow-[0_8px_20px_rgba(124,58,237,0.3)] hover:shadow-[0_12px_28px_rgba(124,58,237,0.4)]",
    secondary: "bg-[var(--bg-surface-2)] border border-[var(--border)] text-[var(--text-primary)] hover:bg-[var(--bg-surface-3)]",
    ghost: "text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:bg-[var(--bg-surface-2)]"
  };
  return <button type={type} onClick={onClick} className={`${base} ${variants[variant]} ${className}`}>{children}</button>
}
