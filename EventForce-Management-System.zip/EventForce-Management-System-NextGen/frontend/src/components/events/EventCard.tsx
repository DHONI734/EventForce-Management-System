import { Card } from '../ui/Card';
import { StatusBadge } from '../ui/Badge';
import type { Event } from '../../services/mockData';
export const EventCard: React.FC<{event: Event, onClick:()=>void}> = ({event, onClick}) => (
  <Card hover className="overflow-hidden cursor-pointer" >
    <div onClick={onClick}>
      <div className="h-28 relative" style={{background: event.gradient}}>
        <div className="absolute top-3 right-3"><StatusBadge status={event.status}/></div>
        <div className="absolute bottom-3 left-3 px-2 py-1 rounded-full bg-white/90 text-[10px] font-bold tracking-wide">{event.category}</div>
      </div>
      <div className="p-4 space-y-3">
        <h3 className="font-display font-semibold text-[15px] leading-tight">{event.name}</h3>
        <div className="text-xs text-[var(--text-secondary)] flex flex-col gap-1">
          <span>{event.date} • {event.time}</span>
          <span>{event.location}</span>
        </div>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2"><div className="w-6 h-6 rounded-full bg-indigo-900 text-white grid place-items-center text-[10px] font-bold">{event.organizer.initial}</div><span className="text-xs">{event.organizer.name}</span></div>
          <span className="text-xs font-medium">{event.attendees}/{event.capacity}</span>
        </div>
        <div className="h-1.5 bg-[var(--bg-surface-2)] rounded-full overflow-hidden"><div className="h-full bg-gradient-to-r from-violet-600 to-cyan-500 transition-all" style={{width:`${event.progress}%`}}/></div>
      </div>
    </div>
  </Card>
)
