export default {
  content: ["./index.html","./src/**/*.{ts,tsx}"],
  theme: { extend: { fontFamily: { display: ['Space Grotesk','sans-serif'], body: ['Inter','sans-serif'] } } }
}
